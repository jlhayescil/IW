﻿/// <reference path="namespace.js" />
var app = app || {}; //app namespace
var appModels = appModels || {};
var appData = appData || {};
var ds = ds || {};
var ajx = ajx || {};

var chg = chg || {};
var hp = hp || {};
